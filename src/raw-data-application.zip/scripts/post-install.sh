#!/bin/bash

if [ ! -d "/home/ubuntu/raw-data-application" ]
then
	sudo mkdir /home/ubuntu/raw-data-application
fi

sudo pwd
sudo mv /data-streaming.py /home/ubuntu/raw-data-application/
sudo mv /requirements.txt /home/ubuntu/raw-data-application/
sudo rm -rf /scripts
sudo rm /appspec.yml
sudo pip3 install -r /home/ubuntu/raw-data-application/requirements.txt
